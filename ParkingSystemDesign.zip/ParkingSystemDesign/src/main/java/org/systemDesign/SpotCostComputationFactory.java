package org.systemDesign;

public class SpotCostComputationFactory {

    private static SpotCostComputationStratergy twoWheelerCostComputation = new TwoWheelerCostComputationStratergy();
    private static SpotCostComputationStratergy fourWheelerCostComputation = new FourWheelerCostComputationStratergy();

    public static SpotCostComputationStratergy getSpotCostComputationStratergy(VehicleType vehicleType){
        if(vehicleType.equals(VehicleType.TWOWHEELER))
            return twoWheelerCostComputation;
        else
            return fourWheelerCostComputation;
    }


}
