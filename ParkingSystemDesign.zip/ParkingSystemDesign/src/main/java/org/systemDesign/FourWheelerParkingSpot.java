package org.systemDesign;

public class FourWheelerParkingSpot extends ParkingSpot{
    public FourWheelerParkingSpot(int parkingSpotId ,ParkingSpotStatus status) {
        super(parkingSpotId, PriceConstant.FOUR_WHEELER_PRICE,status);
    }
}
