package org.systemDesign;

public class CashPaymentMode implements PaymentMode{
    @Override
    public void doPayment(int amount) {
        System.out.println("Cash Payment is done against amount : "+amount);
    }
}
