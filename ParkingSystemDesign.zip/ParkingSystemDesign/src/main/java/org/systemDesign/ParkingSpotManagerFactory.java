package org.systemDesign;

import java.util.ArrayList;

public class ParkingSpotManagerFactory {
    public static ParkingSpotManager twoWheelerParkingSpotManager = new TwoWheelerParkingSpotManager();
    public static ParkingSpotManager fourWheelerParkingSpotManager = new FourWheelerParkingSpotManager();

    public static ParkingSpotManager getParkingSpotManagerFactory(VehicleType vehicleType){
        if(vehicleType.equals(VehicleType.TWOWHEELER))
            return twoWheelerParkingSpotManager;
        else
            return fourWheelerParkingSpotManager;
    }
}
