package org.systemDesign;

public interface PaymentMode {
    public void doPayment(int amount);
}
