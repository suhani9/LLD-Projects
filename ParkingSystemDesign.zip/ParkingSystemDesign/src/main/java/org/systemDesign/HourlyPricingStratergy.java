package org.systemDesign;

public class HourlyPricingStratergy implements PricingStratergy{
    @Override
    public int calculateParkingCost(ParkingTicket ticket) {
        long duration = (System.currentTimeMillis()  - ticket.getEntryTime());
        int spotCostPerHour = ticket.getParkingSpot().getPrice();
        int amount = (int) (spotCostPerHour*duration);
        System.out.println("Cost calculated based on HourlyPricingStratergy : "+amount);
        return amount;
    }
}
