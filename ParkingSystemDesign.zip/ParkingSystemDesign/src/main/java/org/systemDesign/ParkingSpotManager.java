package org.systemDesign;
import java.util.*;
public abstract class ParkingSpotManager {
    private List<ParkingSpot> spotList;
    private ParkingSpotAllocationStratergy parkingSpotAllocationStratergy;

    public List<ParkingSpot> getSpotList() {
        return spotList;
    }

    public ParkingSpotManager() {
        spotList = new ArrayList<>();
    }

    public ParkingSpotManager(List<ParkingSpot> spotList, ParkingSpotAllocationStratergy parkingSpotAllocationStratergy) {
        this.spotList = spotList;
        this.parkingSpotAllocationStratergy = parkingSpotAllocationStratergy;
    }

    public ParkingSpotManager(List<ParkingSpot> spotList) {
        this.spotList = spotList;
    }

    public void setParkingSpotAllocationStratergy(ParkingSpotAllocationStratergy parkingSpotAllocationStratergy) {
        this.parkingSpotAllocationStratergy = parkingSpotAllocationStratergy;
    }

    public Optional<ParkingSpot> findAvailableSpot(Vehicle vehicle , int entryGateId){
        return parkingSpotAllocationStratergy.findSpot(vehicle,entryGateId);
    }
    public void updateParkingSpot(String action , ParkingSpot spot , Vehicle vehicle){
        if(action.equals("PARK") ) {
            spot.parkVehicle(vehicle);
        }
        else{
            spot.removeVehicle(vehicle);
           // parkingSpotAllocationStratergy.vacateParkingSpot(spot);
            spot.setParkingSpotStatus(ParkingSpotStatus.FREE);
        };
    }

    public abstract void addParkingSpot(int SpotId);

    public  void removeParkingSpot(int spotId){
        Optional<ParkingSpot> removedSpot = spotList.stream().filter(ps -> ps.getParkingSpotId() == spotId).findFirst();
        spotList.remove(removedSpot);
    }

}
