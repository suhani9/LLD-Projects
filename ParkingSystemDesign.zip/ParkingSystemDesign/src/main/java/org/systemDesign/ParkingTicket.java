package org.systemDesign;

public class ParkingTicket {
    private long EntryTime;
    private ParkingSpot parkingSpot;
    private  Vehicle vehicle;

    public ParkingTicket(long entryTime, ParkingSpot parkingSpot, Vehicle vehicle) {
        EntryTime = entryTime;
        this.parkingSpot = parkingSpot;
        this.vehicle = vehicle;
    }

    public long getEntryTime() {
        return EntryTime;
    }

    public void setEntryTime(long entryTime) {
        EntryTime = entryTime;
    }

    public ParkingSpot getParkingSpot() {
        return parkingSpot;
    }

    public void setParkingSpot(ParkingSpot parkingSpot) {
        this.parkingSpot = parkingSpot;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
}
