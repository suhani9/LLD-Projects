package org.systemDesign;

import java.util.Optional;

public interface ParkingSpotAllocationStratergy {
    
    public Optional<ParkingSpot> findSpot(Vehicle vehicle , int entryGateId);

    public void vacateParkingSpot(ParkingSpot spot);
}
