package org.systemDesign;

public enum ParkingSpotStatus {
    FREE,
    OCCUPIED;
}
