package org.systemDesign;

import java.util.ArrayList;
import java.util.List;

public class TwoWheelerParkingSpotManager extends ParkingSpotManager{
    public TwoWheelerParkingSpotManager(List<ParkingSpot> spotList, ParkingSpotAllocationStratergy parkingSpotAllocationStratergy) {
        super(spotList, parkingSpotAllocationStratergy);
    }


    public TwoWheelerParkingSpotManager() {
        super();
    }


    @Override
    public void addParkingSpot(int spotId) {
        getSpotList().add(new TwoWheelerParkingSpot(spotId,ParkingSpotStatus.FREE));
    }
}
