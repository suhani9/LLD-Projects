package org.systemDesign;

import java.util.Optional;

public class EntryGate {
    private int entryGateId;

    public EntryGate(int entryGateId) {
        this.entryGateId = entryGateId;
    }

    public int getEntryGateId() {
        return entryGateId;
    }

    public void setEntryGateId(int entryGateId) {
        this.entryGateId = entryGateId;
    }

    public Optional<ParkingTicket> generateTicket(Vehicle vehicle){
        VehicleType vehicleType = vehicle.getVehicleType();
        ParkingSpotManager parkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManagerFactory(vehicleType);
        Optional<ParkingSpot> availableSpot = parkingSpotManager.findAvailableSpot(vehicle, entryGateId);
        if(availableSpot.isPresent()){
            System.out.println("Found parking spot at id : " +availableSpot.get().getParkingSpotId() + " for vehicle : "+vehicle.getLicenseNumber());
            parkingSpotManager.updateParkingSpot("PARK",availableSpot.get(),vehicle);
            return Optional.of(new ParkingTicket(System.currentTimeMillis(), availableSpot.get(), vehicle));
        }
        else{
            System.out.println("Parking is Full for vehicle "+ vehicleType.toString());
            return  Optional.empty();
        }
    }
}
