package org.systemDesign;

import java.util.Optional;

/**
 * This strategy will allocate the parkingSpot nearest to the vehicle's entry gate / exit gate
 * Inorder to implement the nearestToEntry we can maintain the min heap for each entry gate for each spotType ,
 * When the spot is returned from the respective entryGate heap , we remove it from all entryGates's heap
 * distance of any spot from entryGate can be calculated based on their coordinate difference  d = (x-x1)+(y-y1);
 */


public class NearestToEntrySpotAlllocation implements ParkingSpotAllocationStratergy{
    @Override
    public Optional<ParkingSpot> findSpot(Vehicle vehicle, int entryGateId) {
        return Optional.empty();
    }

    @Override
    public void vacateParkingSpot(ParkingSpot spot) {
    //In case of vacating a spot we will have to add the spot in all entrygates min heap.
    }
}
