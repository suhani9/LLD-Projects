package org.systemDesign;

public class PriceConstant {

    public static final int TWO_WHEELER_PRICE = 20;
    public static final int FOUR_WHEELER_PRICE = 40;
}
