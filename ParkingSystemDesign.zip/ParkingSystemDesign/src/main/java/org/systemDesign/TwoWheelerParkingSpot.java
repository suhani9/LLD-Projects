package org.systemDesign;

public class TwoWheelerParkingSpot extends ParkingSpot{
    public TwoWheelerParkingSpot(int parkingSpotId ,ParkingSpotStatus status) {
        super(parkingSpotId , PriceConstant.TWO_WHEELER_PRICE,status);
    }


}
