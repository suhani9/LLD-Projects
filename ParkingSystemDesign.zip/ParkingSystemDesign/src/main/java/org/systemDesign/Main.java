package org.systemDesign;

import java.util.*;

/** Below is the sample to test the ParkingLot System .
 * Consider a system having single floor parking and total parking spot capacity of 30 vehicles with two vehicle types as Two Wheeler Vehicles and Four Wheeler Vehicles.
 *  15 parkingSpots for each type
 * */

public class Main {
    public static void main(String[] args) throws InterruptedException {

        ParkingSpotManager twoWheelerParkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManagerFactory(VehicleType.TWOWHEELER);
        ParkingSpotManager fourWheelerParkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManagerFactory(VehicleType.FOURWHEELER);
        for(int i=0;i<1;i++){
            twoWheelerParkingSpotManager.addParkingSpot(i);
            fourWheelerParkingSpotManager.addParkingSpot(i);
        }
        
        //Lets assume the system uses the randomAllocationStrategy for now 
        twoWheelerParkingSpotManager.setParkingSpotAllocationStratergy(new RandomSpotAllocation());
        fourWheelerParkingSpotManager.setParkingSpotAllocationStratergy(new RandomSpotAllocation());
        
        //creating entry gates
        EntryGate entryGate1 = new EntryGate(1);
        EntryGate entryGate2 = new EntryGate(2);

        //exiting the vehicles from different gate
        ExitGate exitGate1 = new ExitGate(1);
        ExitGate exitGate2 = new ExitGate(2);

        //Let us assume the Two Wheeler Parking spot charges based on fixedPricng and Four Wheeler charges on hourlyPricing
        SpotCostComputationStratergy twoWheelerSpotCostComputation =  SpotCostComputationFactory.getSpotCostComputationStratergy(VehicleType.TWOWHEELER);
        twoWheelerSpotCostComputation.setPricingStratergy(new FixedPricingStratergy());

        SpotCostComputationStratergy fourWheelerSpotCostComputation = SpotCostComputationFactory.getSpotCostComputationStratergy(VehicleType.FOURWHEELER);
        fourWheelerSpotCostComputation.setPricingStratergy(new HourlyPricingStratergy());


        //creating the 4 vehicles 2 of each type making entry from different gates
        Vehicle v1 = new Vehicle("MP093047",VehicleType.TWOWHEELER);
        Vehicle v3 = new Vehicle("MP093048",VehicleType.TWOWHEELER);
        Vehicle v2 = new Vehicle("HR1010987",VehicleType.FOURWHEELER);
        Vehicle v4 = new Vehicle("HR1010987",VehicleType.FOURWHEELER);
        
        //parking the vehicles from different gates
        Optional<ParkingTicket> parkingTicket1 = entryGate1.generateTicket(v1);
        Optional<ParkingTicket> parkingTicket3 = entryGate1.generateTicket(v3);

        Optional<ParkingTicket> parkingTicket2 = entryGate2.generateTicket(v2);
        Optional<ParkingTicket> parkingTicket4 = entryGate1.generateTicket(v4);

        //making the vehicles exit fom different gates post payment passing the
        if(parkingTicket1.isPresent())
        exitGate1.vacateParkingSpot(parkingTicket1.get(),"CASH");
        parkingTicket3 = entryGate1.generateTicket(v3);
        exitGate2.vacateParkingSpot(parkingTicket3.get(),"CARD");
        if(parkingTicket2.isPresent())
        exitGate1.vacateParkingSpot(parkingTicket2.get(),"CASH");
        parkingTicket4 = entryGate1.generateTicket(v4);
        exitGate2.vacateParkingSpot(parkingTicket4.get(),"CARD");


    }
}