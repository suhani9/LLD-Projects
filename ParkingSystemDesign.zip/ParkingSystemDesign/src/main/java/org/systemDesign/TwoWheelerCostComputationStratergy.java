package org.systemDesign;

public class TwoWheelerCostComputationStratergy extends SpotCostComputationStratergy {
    public TwoWheelerCostComputationStratergy() {
        super();
    }
}
