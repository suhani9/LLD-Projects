package org.systemDesign;

import java.util.List;

public class FourWheelerParkingSpotManager extends ParkingSpotManager{
    public FourWheelerParkingSpotManager(List<ParkingSpot> spotList, ParkingSpotAllocationStratergy parkingSpotAllocationStratergy) {
        super(spotList, parkingSpotAllocationStratergy);
    }

    public FourWheelerParkingSpotManager() {
        super();
    }

    @Override
    public void addParkingSpot(int spotId) {
        getSpotList().add(new FourWheelerParkingSpot(spotId ,ParkingSpotStatus.FREE));
    }
}
