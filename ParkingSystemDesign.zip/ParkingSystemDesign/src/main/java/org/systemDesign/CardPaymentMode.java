package org.systemDesign;

public class CardPaymentMode implements PaymentMode{
    @Override
    public void doPayment(int amount) {
        System.out.println("Card Payment is done against amount : "+amount);
    }
}
