package org.systemDesign;

import java.util.UUID;

public abstract class ParkingSpot {
    private int parkingSpotId;
    private ParkingSpotStatus parkingSpotStatus;
    private Vehicle vehicle;
    private int price;

    public ParkingSpot(int parkingSpotId, int spotPrice, ParkingSpotStatus parkingSpotStatus ) {
        this.parkingSpotId = parkingSpotId;
        this.parkingSpotStatus = parkingSpotStatus;
        this.price = spotPrice;
    }

    public int getParkingSpotId() {
        return parkingSpotId;
    }

    public void setParkingSpotId(int parkingSpotId) {
        this.parkingSpotId = parkingSpotId;
    }

    public ParkingSpotStatus getParkingSpotStatus() {
        return parkingSpotStatus;
    }

    public void setParkingSpotStatus(ParkingSpotStatus parkingSpotStatus) {
        this.parkingSpotStatus = parkingSpotStatus;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public int getPrice() {
        return price;
    }


    public void parkVehicle(Vehicle vehicle){
        setVehicle(vehicle);
        setParkingSpotStatus(ParkingSpotStatus.OCCUPIED);
    }

    public void removeVehicle(Vehicle vehicle){
        setVehicle(null);
        setParkingSpotStatus(ParkingSpotStatus.FREE);
    }


}
