package org.systemDesign;

public class ExitGate {
    private int exitGateId;
    public ExitGate(int exitGateId) {
        this.exitGateId = exitGateId;
    }

    public int calculateTicketAmount(ParkingTicket parkingTicket){
        VehicleType vehicleType = parkingTicket.getVehicle().getVehicleType();
        int cost = SpotCostComputationFactory.getSpotCostComputationStratergy(vehicleType).calculateCost(parkingTicket);
        System.out.println(" Parking charges for vehicle  " + parkingTicket.getVehicle().getLicenseNumber() + " "+ vehicleType.toString()+ " is : "+ cost);
        return  cost;
    }

    public void makePayment(String mode,int cost){
        PaymentModeFactory.getPaymentMode(mode).doPayment(cost);
    }

    public void vacateParkingSpot(ParkingTicket parkingTicket,String modeOfPayment){
        int cost = calculateTicketAmount(parkingTicket);
        makePayment(modeOfPayment,cost);
        ParkingSpotManagerFactory.getParkingSpotManagerFactory(parkingTicket.getVehicle().getVehicleType()).updateParkingSpot("VACATE",parkingTicket.getParkingSpot(),parkingTicket.getVehicle());
    }

}
