package org.systemDesign;

public abstract class SpotCostComputationStratergy {
    private PricingStratergy pricingStratergy;

    public PricingStratergy getPricingStratergy() {
        return pricingStratergy;
    }

    public void setPricingStratergy(PricingStratergy pricingStratergy) {
        this.pricingStratergy = pricingStratergy;
    }

    public SpotCostComputationStratergy() {
    }


    public int calculateCost(ParkingTicket parkingTicket){
        return pricingStratergy.calculateParkingCost(parkingTicket);
    }
}
