package org.systemDesign;

public class FixedPricingStratergy implements PricingStratergy{
    @Override
    public int calculateParkingCost(ParkingTicket ticket) {
        int amount = ticket.getParkingSpot().getPrice();
        System.out.println("Cost calculated based on FixedPricingStratergy : "+amount);
        return amount;
    }
}
