package org.systemDesign;

public interface PricingStratergy {
    public int calculateParkingCost(ParkingTicket ticket);
}
