package org.systemDesign;

import java.util.Optional;

public class RandomSpotAllocation implements  ParkingSpotAllocationStratergy{

    @Override
    public Optional<ParkingSpot> findSpot(Vehicle vehicle, int entryGateId) {
        ParkingSpotManager psm = ParkingSpotManagerFactory.getParkingSpotManagerFactory(vehicle.getVehicleType());
        return psm.getSpotList().stream().filter( sp -> sp.getParkingSpotStatus().equals(ParkingSpotStatus.FREE)).findFirst();
    }

    @Override
    public void vacateParkingSpot(ParkingSpot spot) {

    }
}
