package org.systemDesign;

public class PaymentModeFactory {
    public static PaymentMode getPaymentMode(String mode){
        if(mode.equalsIgnoreCase("CASH"))
            return new CashPaymentMode();
        else
            return new CardPaymentMode();
    }
}
