package org.systemDesign;

public enum VehicleType {
    TWOWHEELER,
    FOURWHEELER;
}
