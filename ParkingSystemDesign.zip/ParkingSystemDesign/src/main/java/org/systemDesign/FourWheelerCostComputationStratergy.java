package org.systemDesign;

public class FourWheelerCostComputationStratergy extends SpotCostComputationStratergy{
    public FourWheelerCostComputationStratergy() {
    }
}
