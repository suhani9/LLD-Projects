package org.systemDesign;

import java.util.*;

public class ElevatorController {

    private ElevatorCar elevatorCar;

    public ElevatorCar getElevatorCar() {
        return elevatorCar;
    }

    private ElevatorProcessingStratergy requestProcessingStratergy;
    private ElevatorService service ;
    public void setElevatorCar(ElevatorCar elevatorCar) {
        this.elevatorCar = elevatorCar;
    }

    public ElevatorController(ElevatorCar elevatorCar,ElevatorProcessingStratergy requestProcessingStratergy) {
        this.requestProcessingStratergy = requestProcessingStratergy;
        this.elevatorCar = elevatorCar;
    }

    public void acceptNewRequest(int destFloor , ElevatorDirection direction){
        requestProcessingStratergy.processRequest(destFloor,direction);
    }

    public void controlElevatorCar(){
        while(true){
            try {
                Thread.sleep(10000);
                Optional<Integer> destinationFloor = requestProcessingStratergy.fullFillRequest();
                if(destinationFloor.isPresent()){
                    elevatorCar.setElevatorDirection(destinationFloor.get() >=elevatorCar.getCurrentFloor()?ElevatorDirection.UP:ElevatorDirection.DOWN);
                    elevatorCar.move(destinationFloor.get(),elevatorCar.getElevatorDirection());
                }
                else
                    elevatorCar.setStatus(ElevatorStatus.IDLE);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }
    }


}
