package org.systemDesign;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<ElevatorController> controllers = new ArrayList<>();
        List<Floor> floors = new ArrayList<>();
        for(int i=0;i<3;i++) {
            InternalButton internalButton = new InternalButton(new InternalButtonDispatcher(null));
            Display display = new Display(0,null,ElevatorStatus.IDLE);
            ElevatorCar car = new ElevatorCar(display,0,null,ElevatorStatus.IDLE,internalButton,i);
            controllers.add(new ElevatorController(car,new ElevatorLookStratergy(car)));

        }
        controllers.stream().forEach(c-> c.getElevatorCar().getInternalButton().getDispatcher().setControllerList(controllers));
        for(int i=0;i<7;i++){
            ExternalButton externalButton = new ExternalButton(i,new ExternalButtonDispatcher(controllers,new MinSeekControllerDispatcher()));
            Floor floor = new Floor(i,externalButton);
            floors.add(floor);

        }
        Building building = new Building(floors);

        /* Test case 1 :-
            requesting a going up from 2nd floor and going down from 4th floor
        * */
        floors.get(1).getExternalButton().pressButton(ElevatorDirection.UP);
        controllers.stream().forEach(c -> c.controlElevatorCar());


        controllers.get(0).getElevatorCar().getInternalButton().pressButton(6,0);

        floors.get(4).getExternalButton().pressButton(ElevatorDirection.DOWN);






    }
}