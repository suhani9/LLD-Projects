package org.systemDesign;

public interface InternalDispatchingStratergy {
}
