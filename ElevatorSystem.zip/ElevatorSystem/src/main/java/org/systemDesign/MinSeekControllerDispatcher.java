package org.systemDesign;

import java.util.List;

public class MinSeekControllerDispatcher implements ExternalDispatchingStratergy{
    @Override
    public ElevatorController dipatchController(List<ElevatorController> controllers, int requestFloor, ElevatorDirection requestDirection) {
        int minDist = Integer.MAX_VALUE;
        ElevatorController resultController = null;
        for(ElevatorController controller :controllers){
            int tempDistance ;
            int currentElevatorFloor = controller.getElevatorCar().getCurrentFloor();
            ElevatorDirection direction = controller.getElevatorCar().getElevatorDirection();
            if(controller.getElevatorCar().getStatus().equals(ElevatorStatus.IDLE)){
                tempDistance = Math.abs(currentElevatorFloor-requestFloor);
            }
            else if(requestDirection.equals(controller.getElevatorCar().getElevatorDirection())){
                if((currentElevatorFloor >= requestFloor && direction.equals(ElevatorDirection.DOWN)) || (requestFloor >= currentElevatorFloor && direction.equals(ElevatorDirection.UP))){
                    tempDistance = Math.abs(requestFloor-currentElevatorFloor);
                }
                else
                    tempDistance = 14 + Math.abs(requestFloor-currentElevatorFloor);
            }
            else
                tempDistance = 14 - (requestFloor + currentElevatorFloor);
            if(minDist > tempDistance) {
                minDist = tempDistance;
                resultController = controller;
            }
        }
        return  resultController;
    }

}
