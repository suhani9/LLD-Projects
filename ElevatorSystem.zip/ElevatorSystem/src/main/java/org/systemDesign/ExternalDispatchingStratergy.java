package org.systemDesign;

import java.util.List;

public interface ExternalDispatchingStratergy {
    public ElevatorController dipatchController(List<ElevatorController> controllers , int requestFloor ,ElevatorDirection requestDirection);
}
