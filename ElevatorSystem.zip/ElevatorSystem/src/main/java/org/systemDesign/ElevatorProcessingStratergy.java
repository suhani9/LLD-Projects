package org.systemDesign;

import java.util.Optional;

public interface ElevatorProcessingStratergy {
    public void  processRequest(int destFloor , ElevatorDirection requestDirection);

    public Optional<Integer> fullFillRequest();
    }


