package org.systemDesign;

public class Floor {
    private int floorId;
    private ExternalButton externalButton;

    public int getfloorId() {
        return floorId;
    }

    public void setfloorId(int floorId) {
        this.floorId = floorId;
    }

    public ExternalButton getExternalButton() {
        return externalButton;
    }

    public void setExternalButton(ExternalButton externalButton) {
        this.externalButton = externalButton;
    }

    public Floor(int floorId, ExternalButton externalButton) {
        this.floorId = floorId;
        this.externalButton = externalButton;
    }
}
