package org.systemDesign;

import java.util.*;

public class Building {

    private List<Floor> floorList;

    public Building(List<Floor> floorList) {
        this.floorList = floorList;
    }
}
