package org.systemDesign;

public class InternalButton {
    private InternalButtonDispatcher dispatcher;

    public InternalButton(InternalButtonDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public InternalButtonDispatcher getDispatcher() {
        return dispatcher;
    }

    public void setDispatcher(InternalButtonDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public void pressButton(int destFloor, int elevatorId){
        dispatcher.submitRequest(destFloor,elevatorId);

    }
}
