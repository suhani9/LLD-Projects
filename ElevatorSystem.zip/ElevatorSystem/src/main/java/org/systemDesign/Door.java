package org.systemDesign;

public class Door {
    private boolean isOpen;

    public Door(boolean isOpen) {
        this.isOpen = isOpen;
    }
}
