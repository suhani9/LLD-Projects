package org.systemDesign;

public enum ElevatorDirection {
    UP,DOWN;
}
