package org.systemDesign;

public class ExternalButton {

    private  int floorId;


    private ExternalButtonDispatcher dispatcher;

    public ExternalButton(int floorId, ExternalButtonDispatcher dispatcher) {
        this.floorId = floorId;
        this.dispatcher = dispatcher;
    }

    public void pressButton(ElevatorDirection direction){
        dispatcher.submitRequest(floorId,direction);
    }
}
