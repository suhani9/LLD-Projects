package org.systemDesign;

import java.util.*;

public class InternalButtonDispatcher {

   // private InternalDispatchingStratergy stratergy;
    private List<ElevatorController> controllerList;

    public List<ElevatorController> getControllerList() {
        return controllerList;
    }

    public void setControllerList(List<ElevatorController> controllerList) {
        this.controllerList = controllerList;
    }

    public InternalButtonDispatcher(List<ElevatorController> controllerList) {
       //this.stratergy = stratergy;
        this.controllerList = controllerList;
    }

    public void submitRequest(int destFloor , int elevatorId){
    for(ElevatorController controller : controllerList){
        if(controller.getElevatorCar().getElevatorId()==elevatorId)
            controller.acceptNewRequest(destFloor,controller.getElevatorCar().getElevatorDirection());
    }
    }
}
