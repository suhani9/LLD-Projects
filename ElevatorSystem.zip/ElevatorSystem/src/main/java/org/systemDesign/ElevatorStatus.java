package org.systemDesign;

public enum ElevatorStatus {
    MOVING,IDLE;
}
