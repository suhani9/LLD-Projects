package org.systemDesign;

import java.util.*;

public class ElevatorLookStratergy implements ElevatorProcessingStratergy{
    private ElevatorCar elevatorCar;
    private PriorityQueue<Integer> upRequestQueue;

    private PriorityQueue<Integer> downRequestQueue;

    private List<Integer> pendingRequest;

    public ElevatorLookStratergy(ElevatorCar elevatorCar){
        this.downRequestQueue = new PriorityQueue<>(Collections.reverseOrder());
        this.upRequestQueue = new PriorityQueue<>();
        this.pendingRequest = new ArrayList<>();
        this.elevatorCar = elevatorCar;
    }
    @Override
    public void processRequest(int destFloor, ElevatorDirection requestDirection) {
        System.out.println("accepting the request of " + destFloor + " " + requestDirection);
        System.out.println("Elevator allocated " + elevatorCar.getElevatorId());
        ElevatorDirection currentDirection = elevatorCar.getElevatorDirection();
        int currentFloor = elevatorCar.getCurrentFloor();
        if(elevatorCar.getStatus().equals(ElevatorStatus.IDLE) || requestDirection.equals(currentDirection)){
            if(requestDirection.equals(ElevatorDirection.UP)){
                if(currentFloor<=destFloor)
                    upRequestQueue.add(destFloor);
                else
                    pendingRequest.add(destFloor);
            }
            else{
                if(currentFloor>=destFloor)
                    downRequestQueue.add(destFloor);
                else
                    pendingRequest.add(destFloor);
            }
        }
        else{
            if(currentDirection.equals(ElevatorDirection.UP))
                downRequestQueue.add(destFloor);
            else
                upRequestQueue.add(destFloor);
        }
    }

    @Override
    public Optional<Integer> fullFillRequest() {
        System.out.println("fullFillRequest is called");
        ElevatorDirection currentDirection = elevatorCar.getElevatorDirection();
        if (elevatorCar.getStatus().equals(ElevatorStatus.IDLE)) {
            if(!upRequestQueue.isEmpty())
                return Optional.of(upRequestQueue.poll());
            else if(!downRequestQueue.isEmpty())
                return Optional.of(downRequestQueue.poll());
        } else {
            if (currentDirection.equals(ElevatorDirection.UP)) {
                if (!upRequestQueue.isEmpty()) {
                    return Optional.of(upRequestQueue.poll());
                } else if (!downRequestQueue.isEmpty() && downRequestQueue.peek() >= elevatorCar.getCurrentFloor())
                    return Optional.of(downRequestQueue.poll());
                else if (!downRequestQueue.isEmpty()) {
                    upRequestQueue.addAll(pendingRequest);
                    pendingRequest.clear();
                    return Optional.of(downRequestQueue.poll());
                }
            } else {
                if (!downRequestQueue.isEmpty()) {
                    return Optional.of(downRequestQueue.poll());
                } else if (!upRequestQueue.isEmpty() && upRequestQueue.peek() <= elevatorCar.getCurrentFloor())
                    return Optional.of(upRequestQueue.poll());
                else if (!upRequestQueue.isEmpty()) {
                    downRequestQueue.addAll(pendingRequest);
                    pendingRequest.clear();
                    return Optional.of(upRequestQueue.poll());
                }
            }
        }
        return Optional.empty();
    }
}
