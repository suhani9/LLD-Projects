package org.systemDesign;

import java.util.function.Consumer;

public class ElevatorCar {

    private int elevatorId;
    private Display display;


    public void setDoor(Door door) {
        this.door = door;
    }

    private int currentFloor;

    private ElevatorDirection elevatorDirection;


    private ElevatorStatus status;

    private InternalButton internalButton;

    private Door door;

    public ElevatorCar(Display display, int currentFloor, ElevatorDirection elevatorDirection, ElevatorStatus status, InternalButton internalButton,int elevatorId) {
        this.display = display;
        this.currentFloor = currentFloor;
        this.elevatorDirection = elevatorDirection;
        this.status = status;
        this.internalButton = internalButton;
        this.elevatorId = elevatorId;
    }
    public int getElevatorId() {
        return elevatorId;
    }

    public void setElevatorId(int elevatorId) {
        this.elevatorId = elevatorId;
    }

    public Door getDoor() {
        return door;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public ElevatorDirection getElevatorDirection() {
        return elevatorDirection;
    }

    public void setElevatorDirection(ElevatorDirection elevatorDirection) {
        this.elevatorDirection = elevatorDirection;
    }

    public ElevatorStatus getStatus() {
        return status;
    }

    public void setStatus(ElevatorStatus status) {
        this.status = status;
    }

    public InternalButton getInternalButton() {
        return internalButton;
    }

    public void setInternalButton(InternalButton internalButton) {
        this.internalButton = internalButton;
    }

    public void  move(int dest_floor, ElevatorDirection dest_direction){
        System.out.println("Elevator is moving in " +dest_direction + " to reach floor : "+dest_floor);
        setCurrentFloor(dest_floor);
        display.setCurrentFloor(dest_floor);
        display.setElevatorDirection(dest_direction);
        display.setStatus(ElevatorStatus.MOVING);
        display.displayElevatorStatus();
        
    }
}
