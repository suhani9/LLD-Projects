package org.systemDesign;

public class Display {
    private int currentFloor;
    private  ElevatorDirection elevatorDirection;

    private ElevatorStatus status;

    public ElevatorStatus getStatus() {
        return status;
    }

    public void setStatus(ElevatorStatus status) {
        this.status = status;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public ElevatorDirection getElevatorDirection() {
        return elevatorDirection;
    }

    public void setElevatorDirection(ElevatorDirection elevatorDirection) {
        this.elevatorDirection = elevatorDirection;
    }

    public Display(int currentFloor, ElevatorDirection elevatorDirection , ElevatorStatus status) {
        this.currentFloor = currentFloor;
        this.elevatorDirection = elevatorDirection;
        this.status = status;
    }

    public void displayElevatorStatus(){

        System.out.println("Current floor : "+ currentFloor);
        if(status.equals(ElevatorStatus.IDLE)){
            System.out.println("Elevator car is idle");
        }
        else
            System.out.println("Elevator car is moving in " + elevatorDirection + " direction");
    }
}
