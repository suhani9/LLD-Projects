package org.systemDesign;

import java.util.List;

public class ExternalButtonDispatcher {
   private List<ElevatorController> controllerList;

   public ExternalButtonDispatcher(List<ElevatorController> controllerList, ExternalDispatchingStratergy stratergy) {
      this.controllerList = controllerList;
      this.stratergy = stratergy;
   }


   private ExternalDispatchingStratergy stratergy;
   public void submitRequest(int srcFloor , ElevatorDirection direction){
      ElevatorController controller = stratergy.dipatchController(controllerList,srcFloor,direction);
      controller.acceptNewRequest(srcFloor,direction);
   }
}
