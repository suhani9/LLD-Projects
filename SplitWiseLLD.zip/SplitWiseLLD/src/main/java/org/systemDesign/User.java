package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
public class User {
    private int userId;
    private String username;
    private UserBalanceSheet balanceSheet;

    public User(){
        balanceSheet = new UserBalanceSheet();
    }
}
