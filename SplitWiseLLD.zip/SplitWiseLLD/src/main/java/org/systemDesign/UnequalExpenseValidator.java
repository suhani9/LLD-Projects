package org.systemDesign;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class UnequalExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpense(List<Split> splitList, double amountPaid) {
        return splitList.stream().mapToDouble(split -> split.getAmount()).sum() == amountPaid;
    }
}
