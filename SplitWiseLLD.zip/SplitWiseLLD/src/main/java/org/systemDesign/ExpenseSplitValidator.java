package org.systemDesign;

import java.util.*;

public interface ExpenseSplitValidator {
    public boolean validateExpense(List<Split> splitList, double amountPaid);
}
