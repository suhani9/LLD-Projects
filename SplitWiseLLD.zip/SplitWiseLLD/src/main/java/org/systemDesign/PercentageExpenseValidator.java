package org.systemDesign;

import java.util.List;

public class PercentageExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpense(List<Split> splitList, double amountPaid) {
        return false;
    }
}
