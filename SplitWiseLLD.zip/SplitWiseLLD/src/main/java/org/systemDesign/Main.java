package org.systemDesign;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SplitWiseApp app = new SplitWiseApp();
        app.init();

        //add users
       User user1 =  app.addUser("Suhani",1);
        User user2 =app.addUser("Abhi",2);
        User user3 = app.addUser("Chutka",3);
        User user4 =app.addUser("Advik",4);
        User user5 = app.addUser("Priyanka",5);
        User user6 =app.addUser("Mayank",6);

        //add groups
        app.addGroup("Groceries",01);
        app.addGroup("Lunch",02);

        //add Users to group

        app.addUserToGroup("Groceries",user2);
        app.addUserToGroup("Groceries",user1);
        app.addUserToGroup("Groceries",user3);

        app.addUserToGroup("Lunch",user1);
        app.addUserToGroup("Lunch",user6);

      //  app.displayUserBalanceSheet(user1);

        List<Split> splitList = new ArrayList<>();
        splitList.add( new Split(user1,500.0));
        splitList.add( new Split(user2,500.0));

        //negative test case
//        app.addUserExpense("Trampoline",1100.0,user1,splitList,SplitType.EQUAL);
//        app.displayUserBalanceSheet(user1);

        app.addUserExpense("Trampoline",1000.0,user1,splitList,SplitType.EQUAL);
        System.out.println("Displaying Balance Sheet of "+user1.getUsername());
        app.displayUserBalanceSheet(user1);
        System.out.println("------------------------------------------------");
        System.out.println("Displaying Balance Sheet of "+user2.getUsername());
        app.displayUserBalanceSheet(user2);
        System.out.println("------------------------------------------------");

        //add Expense in Group
        splitList.clear();
        splitList.add(new Split(user1,700.0));
        splitList.add(new Split(user2,500.0));
        splitList.add(new Split(user3,400.0));

        app.addGroupExpense("Groceries","SundayBrunchShop",1600.0,user2,splitList,SplitType.UNEQUAL);
        System.out.println("Displaying Balance Sheet of "+user1.getUsername());
        app.displayUserBalanceSheet(user1);
        System.out.println("------------------------------------------------");
        System.out.println("Displaying Balance Sheet of "+user2.getUsername());
        app.displayUserBalanceSheet(user2);
        System.out.println("------------------------------------------------");
        System.out.println("Displaying Balance Sheet of "+user3.getUsername());
        app.displayUserBalanceSheet(user3);
        System.out.println("------------------------------------------------");

    }
}