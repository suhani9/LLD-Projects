package org.systemDesign;

import lombok.NoArgsConstructor;

import java.util.*;

@NoArgsConstructor
public class BalanceSheetController {
    public void updateUserBalanceSheet(Expense expense){
        List<Split>splitList = expense.getSplitLists();
        User paidByUser = expense.getPaidBy();
        double amountPaid = expense.getAmount();
        for(Split splt : splitList){
            User owedUser = splt.getUserInvolved();
            double perHeadAmt = splt.getAmount();
            if(!owedUser.equals(paidByUser)){
                UserBalanceSheet owedUserBalanceSheet = owedUser.getBalanceSheet();
               owedUserBalanceSheet.setTotalAmountOwe(owedUserBalanceSheet.getTotalAmountOwe()+perHeadAmt);
               owedUserBalanceSheet.setTotalExpense(owedUserBalanceSheet.getTotalExpense()+perHeadAmt);
                owedUserBalanceSheet.getFriendsBalanceList().putIfAbsent(paidByUser.getUsername(),new Balance());
               Balance friendBalance1 = owedUserBalanceSheet.getFriendsBalanceList().get(paidByUser.getUsername());
               friendBalance1.setAmountGetBack(friendBalance1.getAmountGetBack()+perHeadAmt);
               UserBalanceSheet paidUserBalanceSheet = paidByUser.getBalanceSheet();
               paidUserBalanceSheet.getFriendsBalanceList().putIfAbsent(owedUser.getUsername(),new Balance());
               Balance friendBalance2 = paidUserBalanceSheet.getFriendsBalanceList().get(owedUser.getUsername());
               friendBalance2.setAmountOwe(friendBalance2.getAmountOwe()+perHeadAmt);
            }
            else{
                UserBalanceSheet paidUserBalanceSheet = paidByUser.getBalanceSheet();
                paidUserBalanceSheet.setTotalAmountPaid(paidUserBalanceSheet.getTotalAmountPaid()+amountPaid);
                paidUserBalanceSheet.setTotalExpense(paidUserBalanceSheet.getTotalExpense()+amountPaid);
                paidUserBalanceSheet.setTotalAmountGetBack(paidUserBalanceSheet.getTotalAmountGetBack()+(amountPaid-perHeadAmt));
            }
        }
    }
}
