package org.systemDesign;




public enum SplitType {
    EQUAL,
    UNEQUAL,
    PERCENTAGE;
}
