package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.*;

@Data
@AllArgsConstructor
public class Expense {
    private String description;
    private int expenseId;
    private double amount;
    private User paidBy;
    private  SplitType type;
    private List<Split> splitLists;

}
