package org.systemDesign;

import lombok.Data;

@Data
public class Balance {
    private double amountOwe;
    private double amountGetBack;
}
