package org.systemDesign;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;

@Data
public class UserBalanceSheet {
    private Map<String,Balance> friendsBalanceList;
    private double totalAmountOwe ;
    private double totalAmountPaid;
    private double totalAmountGetBack;
    private double totalExpense;

    public UserBalanceSheet() {
        friendsBalanceList = new HashMap<>();
    }

    public void display(){
        System.out.println("Total owed : " + totalAmountOwe);
        System.out.println("Total get back : " + totalAmountGetBack);
        System.out.println("Total Payment done : "+totalAmountPaid);
        System.out.println("Total Expense : "+totalExpense);
        System.out.println("Friend Balance");
        for(Map.Entry<String,Balance> entry : friendsBalanceList.entrySet()){
            System.out.println(entry.getKey() + " " + entry.getValue().toString());
        }

    }
}
