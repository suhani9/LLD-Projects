package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
public class Group {
    private int groupId;
    private List<User>members;
    private String groupName;
    private List<Expense> expenseList;
    private ExpenseController expenseController;

    public Group(ExpenseController expenseController) {
        members = new ArrayList<>();
        expenseList = new ArrayList<>();
        this.expenseController = expenseController;
    }
}
