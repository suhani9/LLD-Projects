package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Data

public class UserController {
    private List<User> userList;

    public UserController() {
        userList = new ArrayList<>();
    }

    public User addUser(String userName , int userId){
        User newUser = new User();
        newUser.setUserId(userId);
        newUser.setUsername(userName);
        userList.add(newUser);
        return newUser;
    }

    public  void removeUser(User oldUser){
        userList.remove(oldUser);
    }
}
