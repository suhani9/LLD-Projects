package org.systemDesign;

import java.util.List;

public class EqualExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpense(List<Split> splitList, double amountPaid) {
        double calculatedPerHead = amountPaid/splitList.size();
        return splitList.stream().allMatch(split -> split.getAmount().equals(calculatedPerHead));
    }
}
