package org.systemDesign;

public class ExpenseSplitFactory {

    public static ExpenseSplitValidator getSplitValidator(SplitType type){
        if(type.equals(SplitType.EQUAL))
            return new EqualExpenseValidator();
        else if(type.equals(SplitType.UNEQUAL))
            return new UnequalExpenseValidator();
        else
            return new PercentageExpenseValidator();
    }
}
