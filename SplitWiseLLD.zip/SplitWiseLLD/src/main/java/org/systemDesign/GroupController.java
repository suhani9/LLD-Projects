package org.systemDesign;

import lombok.Data;

import javax.swing.plaf.PanelUI;
import java.util.ArrayList;
import java.util.List;

@Data
public class GroupController {
    private List<Group> groupList;
    private ExpenseController expenseController;

    public GroupController(){
        groupList = new ArrayList<>();
    }
    public void addMember(Group grp ,User newMember){
       Group groupFound =  groupList.stream().filter(g -> g.equals(grp)).findAny().get();
       groupFound.getMembers().add(newMember);
    }

    public void removeMember(Group grp , User oldMember){
        Group groupFound =  groupList.stream().filter(g -> g.equals(grp)).findAny().get();
        groupFound.getMembers().remove(oldMember);
    }

    public Expense addExpense(Group grp , String description ,double amount, User paidBy, List<Split>splitList,SplitType type){
        Group groupFound =  groupList.stream().filter(g -> g.equals(grp)).findAny().get();
        Expense newExpense = groupFound.getExpenseController().createExpense(description,amount,paidBy,splitList,type);
        if(newExpense !=null)
            groupFound.getExpenseList().add(newExpense);
        return  newExpense;
    }

    public Group addGroup(String groupName , int groupId,ExpenseController expenseController){
    Group newGroup = new Group(expenseController);
    newGroup.setGroupName(groupName);
    newGroup.setGroupId(groupId);
    groupList.add(newGroup);
    return newGroup;
    }
    public void removeGroup(Group group){
        groupList.remove(group);
    }


}
