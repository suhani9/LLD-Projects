package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Split {
    private User userInvolved;
    private Double amount;
}
