package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Optional;

@Data
@NoArgsConstructor
public class SplitWiseApp {
    private GroupController groupController;
    private UserController userController;
    private ExpenseController expenseController;

    public void init(){
        groupController = new GroupController();
        userController = new UserController();
        expenseController = new ExpenseController(new BalanceSheetController());
    }

    public User addUser(String userName , int userId){
        User newUser = userController.addUser(userName,userId);
        System.out.println("New User created" + newUser.toString());
        return newUser;
    }

    public void addGroup(String groupName , int groupId){
       Group newGroup= groupController.addGroup(groupName,groupId,expenseController);
        System.out.println("New group created" + newGroup.toString());
    }

    public void addUserToGroup(String groupName , User user){
        Optional<Group> found = groupController.getGroupList().stream().filter(group -> group.getGroupName().equals(groupName)).findAny();
        groupController.addMember(found.get(),user);
    }

    public void addUserExpense(String description , double amount, User paidBy, List<Split> splitList, SplitType type){
        expenseController.createExpense(description,amount,paidBy,splitList,type);
    }

    public void addGroupExpense(String groupName ,String description , double amount, User paidBy, List<Split> splitList, SplitType type){
        Optional<Group> found = groupController.getGroupList().stream().filter(group -> group.getGroupName().equals(groupName)).findAny();
        groupController.addExpense(found.get(),description,amount,paidBy,splitList,type);
    }

    public  void displayUserBalanceSheet(User user){
        user.getBalanceSheet().display();
    }
}
