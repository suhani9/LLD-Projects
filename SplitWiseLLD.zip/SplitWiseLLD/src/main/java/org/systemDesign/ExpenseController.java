package org.systemDesign;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class ExpenseController {

    private BalanceSheetController balanceSheetController;

    public Expense createExpense(String description ,double amount, User paidBy, List<Split>splitList,SplitType type){
        ExpenseSplitValidator validator = ExpenseSplitFactory.getSplitValidator(type);
        Expense expense = null;
        if(validator.validateExpense(splitList,amount)){
            expense = new Expense(description,1,amount,paidBy,type,splitList);
            balanceSheetController.updateUserBalanceSheet(expense);
        }
        else{
            System.out.println("Invalid Expense based on type");
        }
        return  expense;
    }
}
